package br.com.excecao.beans;

import java.util.Scanner;

public class TesteDoisErrosVersaoNove {

		   private static Scanner scan;



		   public static void main(String[] args) {



		       System.out.println("Entre com um n�mero: ");
		        try {
		            int recebeNum = lerNumero();
		            System.out.println("Voc� digitou o n�mero " + recebeNum);
		        }catch (Exception e) {
		            System.out.println("Entrada inv�lida");
		            e.printStackTrace();
		        }
		    }
		    
		    public static int lerNumero() throws Exception {
		        //int receberNumero = Integer.parseInt(JOptionPane.showInputDialog("Digite um n�mero"));
		        scan = new Scanner(System.in);
		        int recebeNum = scan.nextInt();
		        return recebeNum;
		    }
}
