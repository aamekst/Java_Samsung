package br.com.samsung.teste;

import javax.swing.JOptionPane;

import br.com.samsung.beans.tv;

public class ProgramDois {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int indice = 0, vltg = 220;
		double alt =100, lgr =  800, ps = 2;
		String nomeModelo = null;
		
		tv[] TV = new tv[3];
		
		
		int resp = 0;
		while (resp == 0)
		{
			/*TV[indice] = new tv();
			TV[indice].setAltura(alt);
			TV[indice].setLargura(lgr);
			TV[indice].setModelo(nomeModelo);
			TV[indice].setPeso(ps);
			TV[indice].setVoltagem(vltg);*/
			
			nomeModelo = JOptionPane.showInputDialog("Nome do modelo");
			vltg = Integer.parseInt(JOptionPane.showInputDialog("Digite a voltagem:"));

			
			indice++;
			JOptionPane.showConfirmDialog(null, "deseja continuar?", "Cmadas!", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			
			
		}
		
		for(tv TV : tv)
		{
			System.out.println(+TV.getAltura() + tv.getPeso());
		}
		
	}

}
