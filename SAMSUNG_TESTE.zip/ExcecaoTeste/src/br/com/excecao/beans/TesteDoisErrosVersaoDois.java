package br.com.excecao.beans;

public class TesteDoisErrosVersaoDois {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	        
	        int[] numero =      {2, 4, 8, 16, 32, 64};
	        int[] denominador = {2, 2, 0, 2,  0};
	        
	        for (int i=0; i<numero.length; i++) {
	            try {
	                System.out.println("Resulado: " + numero[i]/denominador[i]);
	            }
	            catch (ArithmeticException exc) {
	                System.out.println("Ocorreu um erro durante a execu��o do for,"
	                        + " pois tentou dividir um n�mero por zero");
	            }
	        }
	    
	}

}
