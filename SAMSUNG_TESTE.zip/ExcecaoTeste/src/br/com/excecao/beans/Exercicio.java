package br.com.excecao.beans;

public class Exercicio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = {4, 15, 7, 12, 32 ,64};
		int [] b = {43,5 ,2};
		int[] resul =  {172, 75, 14};
		
		
		for (int i=0; i<a.length; i++)
		{
			
			try {
                System.out.println("Resultado: " + a[i]*b[i]);
                resul[i] = a[i]*b[i];
            }
            catch (ArithmeticException exc) {
                System.out.println("Ocorreu um erro durante a execu��o do for,");
             
            }
			catch (ArrayIndexOutOfBoundsException exc) {
                System.out.println("Ocorreu um erro, pois tentou fazer a multiplica��o "
                        + "por uma posi��o que n�o existe no vetor.");
            }
}
}
}

