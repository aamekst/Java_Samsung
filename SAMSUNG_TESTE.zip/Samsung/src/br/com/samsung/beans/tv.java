package br.com.samsung.beans;

public class tv {
	
	private double largura;
	private double altura;
	private int voltagem;
	private String modelo;
	private static double peso;
	
	public double getLargura() {
		return largura;
	}
	public static double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public void setLargura(double largura) {
		this.largura = largura;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	public int getVoltagem() {
		return voltagem;
	}
	public void setVoltagem(int voltagem) {
		this.voltagem = voltagem;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	public static String pesoTotal(double receberpeso)
	{
		double pesoTotal = getPeso() + receberpeso;
		return("o peso da tv �: " + pesoTotal);
	}

}
