package br.com.excecao.beans;

public class TesteDoisErrosVersaoTres {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	        
	        int[] numero = {2,  4, 8, 16, 32, 64};
	        int[] denom =  {2,  2, 0,  2,  0};
	        
	        for (int i=0; i<numero.length; i++) {
	            try {
	                System.out.println("Resulado: " + numero[i]/denom[i]);
	            }
	            catch (ArithmeticException exc) {
	                System.out.println("Ocorreu um erro durante a execu��o do for,"
	                        + " pois tentou dividir um n�mero por zero");
	            }
	            catch (ArrayIndexOutOfBoundsException exc) {
	                System.out.println("Ocorreu um erro, pois tentou fazer a divis�o "
	                        + "por uma posi��o que n�o existe no vetor.");
	            }
	        }
	    
	}

}
