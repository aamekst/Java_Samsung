package br.com.samsung.teste;

import br.com.samsung.beans.tv;

public class Programa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		tv TV = new tv();
		
		
		TV.setAltura(0);
		TV.setLargura(0);
		TV.setModelo(null);
		TV.setVoltagem(0);
		TV.setPeso(1.3);
		
		
		System.out.println(tv.pesoTotal(1.3));
	
		

	}

}
